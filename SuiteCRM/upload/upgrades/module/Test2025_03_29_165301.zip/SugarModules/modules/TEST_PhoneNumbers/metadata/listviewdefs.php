<?php
$module_name = 'TEST_PhoneNumbers';
$listViewDefs [$module_name] = 
array (
  'PHONE_NUMBER' => 
  array (
    'type' => 'phone',
    'label' => 'LBL_PHONE_NUMBER',
    'width' => '10%',
    'default' => true,
  ),
);
;
?>
